
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.item.UnpolishedRubyItem;
import net.mcreator.item.RubyshardItem;
import net.mcreator.item.RubyOnAStikItem;
import net.mcreator.item.PolishedRubyItem;
import net.mcreator.ModForLifestealMod;

public class ModForLifestealModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ModForLifestealMod.MODID);
	public static final RegistryObject<Item> UNPOLISHED_RUBY = REGISTRY.register("unpolished_ruby", () -> new UnpolishedRubyItem());
	public static final RegistryObject<Item> RUBY_ORE = block(ModForLifestealModBlocks.RUBY_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> POLISHED_RUBY = REGISTRY.register("polished_ruby", () -> new PolishedRubyItem());
	public static final RegistryObject<Item> RUBY_ON_A_STIK = REGISTRY.register("ruby_on_a_stik", () -> new RubyOnAStikItem());
	public static final RegistryObject<Item> RUBYSHARD = REGISTRY.register("rubyshard", () -> new RubyshardItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
